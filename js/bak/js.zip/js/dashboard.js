/*
 * Author: Abdullah A Almsaeed
 * Date: 4 Jan 2014
 * Description:
 *      This is a demo file used only for the main dashboard (index.html)
 **/

$(function () {
  $('.daterange').daterangepicker({
    ranges   : {
      'Today'       : [moment(), moment()],
      'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
      'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
      'Last 30 Days': [moment().subtract(29, 'days'), moment()],
      'This Month'  : [moment().startOf('month'), moment().endOf('month')],
      'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
    },
    startDate: moment().subtract(29, 'days'),
    endDate  : moment()
  }, function (start, end) {
    window.alert('You chose: ' + start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
  });

  // The Calender
  $('.date').datepicker({
    format: 'yyyy-mm-dd'
  });

  $('.year').datepicker({
    format: 'yyyy',
    viewMode : 'years',
    minViewMode : 'years'
  });
  
  $('.DataTable').DataTable();

  $('[data-toggle="tooltip"]').tooltip();
  $('[data-tooltip="tooltip"]').tooltip();

  $('.timepicker').timepicker({
      showInputs: false,
      showMeridian: false
    })
});
